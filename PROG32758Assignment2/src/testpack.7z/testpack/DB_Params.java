package testpack;

public interface DB_Params {
	public final String url = "jdbc:mysql://localhost:3306/test";
	public final String driver = "com.mysql.jdbc.Driver";
	public final String userName = "root";
	public final String userPass = "password";
}
